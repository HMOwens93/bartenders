<?php
// Please make a copy of this file as 'config.php' and then edit the config values below.

// global configuration array that we will use throughout the application
global $conf;
// DB connection string
$conf['db']['url'] = 'mysql:host=localhost;dbname=dev_hannahowens_bartender';
$conf['db']['username'] = 'hannahowens';
$conf['db']['password'] = '5abb611e9b3707db766434f16650d289';


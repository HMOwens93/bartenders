<?php

class WelcomeController extends Controller {
  public function __construct($server, $request) {
    parent::__construct($server, $request);
  }

  public function GET() {
    $view = new View('welcome');
    $params = array();
    $view->render($params);
  }
}
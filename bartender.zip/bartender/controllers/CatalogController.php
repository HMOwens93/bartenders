<?php

class CatalogController extends Controller {
  public function __construct($server, $request) {
    parent::__construct($server, $request);
  }
  
  public function GET() {
    $m = new Model($this->db, 'catalog_item');
    $items = $m->get_many();
    $v = new View('items');
    $v->render(array('items' => $items));
  }
  
  public function POST() {
    $m = new Model($this->db, 'item_order');
    $order = array('item_id' => $this->request['id']);
    $m->save($order);
    $this->GET();
  }
}
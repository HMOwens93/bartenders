<?php

class OrderController extends Controller {
  public function __construct($server, $request) {
    parent::__construct($server, $request);
  }
  
  public function GET() {
    $m = new Model($this->db, 'item_order');
    $orders = $m->get_where('fill_status IS NULL');
    $v = new View('orders');
    $v->render(array('orders' => $orders));
  }
  
  public function POST() {
    $m = new Model($this->db, 'item_order');
    $order = array('id' => $this->request['id'], 'fill_status' => $this->request['status']);
    $m->save($order);
    $this->GET();
  }
}
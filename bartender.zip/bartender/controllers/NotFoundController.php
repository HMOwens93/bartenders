<?php

class NotFoundController extends Controller {
  public function __construct($server, $request) {
    parent::__construct($server, $request);
  }
  
  public function GET() {
    $view = new View('not_found');
    $params = array('uri' => $this->requestURI);
    http_response_code(404);
    $view->render($params);
  }
}
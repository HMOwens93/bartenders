<?php


error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// define the REQUEST_TIME constant as the timestamp of the request
define('REQUEST_TIME', (int) $_SERVER['REQUEST_TIME']);

global $conf;
$conf = array();
require_once 'config.php';

class Model {
  protected $db;
  protected $table;
  protected $id_column = 'id';

  public function __construct($db, $table, $id_column = 'id') {
    $this->db = $db;
    $this->table = $table;
    $this->id_column = $id_column;
  }

  // fetch many with a WHERE clause
  public function get_where($where = NULL, $limit = 100, $offset = 0) {
    $sql = 'SELECT * FROM ' . $this->table;
    if($where) {
      $sql .= ' WHERE ' . $where;
    }
    $sql .= ' LIMIT :limit OFFSET :offset';
    $st = $this->db->prepare($sql);
    $st->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
    $st->bindValue(':offset', (int) $offset, PDO::PARAM_INT);
    if($st->execute()) {
      return $st->fetchAll(PDO::FETCH_ASSOC);
    }
  }

  // fetch many without a WHERE clause
  public function get_many($limit = 100, $offset = 0) {
    return $this->get_where(NULL, $limit, $offset);
  }

  // fetch single row with the primary key specified
  public function get_one($id) {
    $st = $db->prepare('SELECT * FROM ' . $table . ' WHERE ' . $this->id_column . ' = :id');
    if($st->execute(['id' => $id])) {
      return $st->fetch(PDO::FETCH_ASSOC);
    }
  }

  // save the given record (INSERT or UPDATE)
  public function save(array $record) {
    if(isset($record[$this->id_column])) {
      return $this->update($record);
    } else {
      return $this->insert($record);
    }
  }

  protected function insert($record) {
    $column_names = $this->get_column_names();
    $sql = 'INSERT INTO ' . $this->table . ' (';
    foreach($column_names as $idx => $col) {
      if(array_key_exists($col, $record)) {
        $sql .= $col;
      }
    }
    $sql .= ') VALUES (';
    foreach($column_names as $idx => $col) {
      if(array_key_exists($col, $record)) {
        $sql .= ':' . $col;
      }
    }
    $sql .= ')';
    $st = $this->db->prepare($sql);
    if($st->execute($record)) {
      return $this->db->lastInsertId();
    }
  }

  protected function update($record) {
    $column_names = $this->get_column_names();
    $sql = 'UPDATE ' . $this->table . ' SET ';
    $first = TRUE;
    foreach($column_names as $idx => $col) {
      if(array_key_exists($col, $record)) {
        if($first) {
          $first = FALSE;
        } else {
          $sql .= ', ';
        }
        $sql .= $col . '=:' . $col;
      }
    }
    $sql .= ' WHERE ' . $this->id_column . '=:' . $this->id_column;
    $st = $this->db->prepare($sql);
    return $st->execute($record);
  }

  protected function get_column_names() {
    static $column_names = array();
    if(empty($column_names)) {
      $rs = $this->db->query('SELECT * FROM ' . $this->table . ' LIMIT 0');
      for ($i = 0; $i < $rs->columnCount(); $i++) {
        $col = $rs->getColumnMeta($i);
        if($col['name'] != $this->id_column) {
          $column_names[] = $col['name'];
        }
      }
    }
    return $column_names;
  }
}

class View {
  protected $view_template;
  public function __construct($view_name) {
    $this->view_template = 'views/' . $view_name . '.php';
  }
  
  public function render($params = array()) {
    ob_start();
    extract($params);
    include $this->view_template;
    ob_end_flush();
  }
}

class Controller {
  protected $requestMethod;
  protected $requestURI;
  protected $server;
  protected $request;
  public function __construct($server, $request) {
    global $conf;
    $this->requestMethod = strtoupper($server['REQUEST_METHOD']);
    $this->requestURI = $server['PATH_INFO'];
    $this->server = $server;
    $this->request = $request;
    // the next line causes PDO to throw an exception every time a database error occurs
    $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    // connect to the database using the $conf global configuration
    $this->db = new PDO($conf['db']['url'], $conf['db']['username'], $conf['db']['password'], $pdo_options);
  }

  public function __toString() {
    return  $this->requestMethod . ' - ' . $this->requestURI;
  }
  
  public function GET() {
      
  }

  public function POST() {
    return $this->GET();
  }

  public function process() {
    switch ($this->requestMethod) {
      case 'POST':
        $this->POST();
        break;
      default:
        $this->GET();
    }
  }
}

$routes = array(
  NULL => 'WelcomeController',
  '/' => 'WelcomeController',
  '/catalog' => 'CatalogController',
  '/orders' => 'OrderController',
);

// extract the request URI from $_SERVER super-global
$uri = $_SERVER['PATH_INFO'];
if(array_key_exists($uri, $routes)) {
  $controller = $routes[$uri];
} else {
  $controller = 'NotFoundController';
}

require_once 'controllers/' . $controller . '.php';
$c = new $controller($_SERVER, $_REQUEST);
$c->process();

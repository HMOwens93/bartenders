<!DOCTYPE html>
<html>
  <body>
    <h1>Not Found</h1>
    <p>Path not found: <?php echo $uri; ?>.</p>
    <p>Back to <a href="/">home page</a></p>
  </body>
</html>
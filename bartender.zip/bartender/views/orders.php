<!DOCTYPE html>
<html>
  <head>
    <title>Fill Orders</title>
  </head>
  <body style="background-color: #FEF9E7">
    <h1 align="center">Fill Orders</h1>
    <hr>
    <?php if (empty($orders)): ?>
      <p>No orders found.<a href="/catalog"> Want some?</a></p>
    <?php else: ?>
      <h2>Orders</h2>
      <table>
        <thead>
        <th>Name</th>
        <th>ID</th>
        <th>&nbsp;</th>
      </thead>
      <tbody>
        <?php foreach ($orders as $order): ?>
          <tr>
            <td><?php echo $order['id']; ?></td>
            <td><?php echo $order['item_id']; ?></td>
            <td>
              <form method="POST">
                <input name="id" type="hidden" value="<?php echo $order['id']; ?>">
                <button type="submit" name="status" value="1">Fill Order</button>
                <button type="submit" name="status" value="0">Cancel Order</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
    </table>
  <?php endif; ?>
  <p>Back to <a href="/">home page</a></p>
</body>
</html>
<!DOCTYPE html>
<html>
  <head>
    <title>Drink List</title>
  </head>
  <body style="background-color: #FEF9E7">
    <h1 align="center">Drinks</h1>
    <p align="center">The finest around</p>
    <hr>
    <table>
      <thead>
        <tr>
          <th>&nbsp;</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
          <tr>
            <td><?php echo $item['title']; ?></td>
            <td>
                <form method="POST">
                  <input name="id" type="checkbox" value="<?php echo $item['id']; ?>">
                  <input type="submit" value="Fill orders">
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <br>
    <p><a href="/orders">Fill orders</a>.</p>
    <p>Back to <a href="/">home page</a></p>
  </body>
</html>
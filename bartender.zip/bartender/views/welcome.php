<!DOCTYPE html>
<html>
  <head>
    <title>Bartender</title>
  </head>
  <body style="background-color: #FEF9E7">
    <h1 align='center'>Welcome to the Bar</h1>
    <p align='center'>Enjoy our wide selection of unique beverages</p>
    <hr>
    <ul>
        <li><a href="/catalog">Choose a drink</a>.</li>
    </ul>
  </body>
</html>